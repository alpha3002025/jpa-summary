package io.summary.jpa.inheritance_entity_mapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InheritanceEntityMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
