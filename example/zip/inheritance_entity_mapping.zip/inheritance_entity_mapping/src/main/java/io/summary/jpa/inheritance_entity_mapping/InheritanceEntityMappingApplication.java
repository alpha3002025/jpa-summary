package io.summary.jpa.inheritance_entity_mapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InheritanceEntityMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(InheritanceEntityMappingApplication.class, args);
	}

}
