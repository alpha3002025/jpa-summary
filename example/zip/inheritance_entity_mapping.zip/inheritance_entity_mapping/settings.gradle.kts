rootProject.name = "inheritance_entity_mapping"
