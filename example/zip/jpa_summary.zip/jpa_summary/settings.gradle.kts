rootProject.name = "jpa_summary"
