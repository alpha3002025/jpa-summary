package io.summary.jpa.jpa_summary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaSummaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaSummaryApplication.class, args);
	}

}
