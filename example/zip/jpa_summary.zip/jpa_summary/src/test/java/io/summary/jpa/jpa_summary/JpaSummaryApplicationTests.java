package io.summary.jpa.jpa_summary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaSummaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
